const TRANSFORMATION_TYPES = [
  { title: 'A enero', value: 'ENE' },
  { title: 'A febrero', value: 'FEB' },
  { title: 'A marzo', value: 'MAR' },
  { title: 'A abril', value: 'ABR' },
  { title: 'A mayo', value: 'MAY' },
  { title: 'A junio', value: 'JUN' },
  { title: 'A julio', value: 'JUL' },
  { title: 'A agosto', value: 'AGO' },
  { title: 'A septiembre', value: 'SEP' },
  { title: 'A octubre', value: 'OCT' },
  { title: 'A noviembre', value: 'NOV' },
  { title: 'A diciembre', value: 'DIC' }
];

module.exports = { TRANSFORMATION_TYPES };
